     This is a School Website and Portal ( Higher Institution ).
     It's built for an Online School. Applicants can apply to enroll and 
     if they are given admission, they begin clearance processes and they
     will have access to their portals and do varieties of things on the portal. 
     The School runs a degree programme, Diploma programme
     as well as Certificate programme ( Vocational works ).
