
<?php $__env->startSection('content'); ?>
    <main id="main" class="main">
        <a id="main-content" tabindex="-1"></a>
        <div class="region region-breadcrumb">
            <div data-drupal-messages-fallback class="hidden"></div>

            <div id="block-breadcrumbs"
                class="breadcrumb-block--orange block breadcrumb-block block-system block-system-breadcrumb-block">
                <div class="breadcrumb-block__inner">
                    <div class="container">
                        <nav class="breadcrumb" role="navigation" aria-labelledby="system-breadcrumb">
                            <h2 id="system-breadcrumb" class="visually-hidden">Breadcrumb</h2>
                            <ol>
                                <li>
                                    <a href="<?php echo e(url('/')); ?>">Home</a>
                                </li>
                                <li>
                                    <a href="<?php echo e(url('programs')); ?>">Programs</a>
                                </li>
                                <li>
                                    Demography and Social Statistics B.Sc.
                                </li>
                            </ol>
                        </nav>

                    </div>
                </div>
            </div>

        </div>

        <div class="container main-content">
            <div class="region region-content">
                <div id="block-mainpagecontent" class="block block-system block-system-main-block">
                    <div class="field__item" tabindex="0">
                        <div>


                            <div class="feature-banner has-image">
                                <div class="feature-banner__image">
                                    <picture>
                                        <source srcset="assets/img/admission-banner.jpg?h=4da1fa98&amp;itok=yaN7h3BB 1x"
                                            media="screen and (min-width: 90em)" type="image/png" />
                                        <source srcset="assets/img/admission-banner.jpg?h=4da1fa98&amp;itok=ODq8_SVs 1x"
                                            media="screen and (min-width: 64em)" type="image/png" />
                                        <source srcset="assets/img/admission-banner.jpg?h=4da1fa98&amp;itok=kGzeO0oN 1x"
                                            media="(min-width: 0em)" type="image/png" />
                                        <img src="assets/img/admission-banner.jpg?itok=mkYpVdvv" alt="Pixels Bench"
                                            title="pixel_bench_crop.png" typeof="foaf:Image" />

                                    </picture>

                                </div>
                                <div class="feature-banner__content-wrap">
                                    <div class="container">
                                        <div class="feature-banner__content text--center bg--black text--white">
                                            <h1 class="feature-banner__title">Demography and Social Statistics B.Sc.</h1>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

        </div>
        <div class="tab-body">
          <div class="tab">
            <button class="tab-button" onclick="openTab(event, 'tab1')"><h4>Course info</h4></button>
            <button class="tab-button" onclick="openTab(event, 'tab2')"><h4>Program Requirements</h4></button>
            <button class="tab-button" onclick="openTab(event, 'tab3')"><h4>Career Opportunities</h4> </button>
            <button class="tab-button" onclick="openTab(event, 'tab4')"><h4>Program Cost</h4></button>
          </div>
        
          <div id="tab1" class="tab-content">
            <p>Our Demography and Social Statistics program is designed to provide students with a strong foundation in both demographic analysis and social statistics. The program combines theoretical knowledge with practical skills to enable students to understand and analyze population dynamics, social trends, and statistical data. The curriculum covers various topics such as population composition, migration, fertility, mortality, social inequality, survey design, data collection, and data analysis techniques.</p>
            <p><b>Program Structure:</b> </p>
            <ol>
                <li>
                  <strong>Core Courses:</strong> The program includes a set of core courses that provide a comprehensive understanding of demography and social statistics. These courses cover foundational concepts, theories, and methodologies in both fields.
                </li>
                <li>
                  <strong>Elective Courses:</strong> Students can choose from a range of elective courses based on their interests and career goals. Electives may include advanced topics in demography, social statistics, research methods, data visualization, and programming for data analysis.
                </li>
                <li>
                  <strong>Internship/Practicum:</strong> The program may include an internship or practicum component where students gain hands-on experience working with real-world data and applying statistical techniques in a professional setting.
                </li>
                <li>
                  <strong>Research Project:</strong> Students may be required to complete a research project in their final year, allowing them to demonstrate their ability to apply their knowledge and skills to a specific area of demography or social statistics.
                </li>
            </ol>
            <p><b>Program Outcomes:</b> Upon completion of the Demography and Social Statistics B.Sc. program, graduates will be able to:</p>
            <ol>
                <li>Understand and analyze population dynamics and social trends using demographic and statistical concepts and theories.</li>
                <li>Collect, manage, and analyze data using appropriate statistical software and techniques.</li>
                <li>Design and implement surveys and other data collection methods.</li>
                <li>Interpret and present statistical findings effectively through written reports, visualizations, and presentations.</li>
                <li>Apply statistical methods to address research questions related to population, social inequality, and other relevant areas.</li>
                <li>Work collaboratively and ethically in multidisciplinary teams to tackle real-world problems.</li>
                <li>Utilize critical thinking and problem-solving skills to address issues related to population and social statistics.</li>
                <li>Pursue advanced studies or careers in demography, social statistics, public policy, market research, social sciences, and related fields.</li>
            </ol>
          </div>
        
          <div id="tab2" class="tab-content">
            <ol>
              <li>Original Waec, or Neco certificate</li>
              <li>Online/computer print of waec with scratch card attached</li>
              <li>Transcript from previous university</li>
              <li>Jamb result (Optional)</li>
              <li>Two passport photos</li>
              <li>Valid form of identification: [international passport, Voter’s Card, NIN, etc…]</li>
              <li>Birth Certificate or Local government ID</li>
            </ol>
          </div>
        
          <div id="tab3" class="tab-content">
            <h4>Career Opportunities for Demography and Social Statistics B.Sc. Graduates:</h4>
            <p>Demography and Social Statistics graduates possess a unique skill set that equips them for a range of exciting career opportunities. Here are some potential career paths for graduates with a B.Sc. in Demography and Social Statistics:</p>
            <ol>
                <li><strong>Demographer:</strong> Work as a demographer for government agencies, research institutions, or non-profit organizations, analyzing population data, conducting demographic research, and providing insights into population trends and patterns.</li>
                <li><strong>Data Analyst:</strong> Use your statistical and analytical skills to work as a data analyst in various sectors such as market research, social research, healthcare, or government agencies. Analyze data sets, extract meaningful insights, and provide data-driven recommendations.</li>
                <li><strong>Researcher:</strong> Conduct research on social issues, population dynamics, or public policy. Work in academic institutions, think tanks, or research organizations to contribute to the understanding of social phenomena and inform policy decisions.</li>
                <li><strong>Social Statistician:</strong> Apply statistical techniques to analyze and interpret social data related to education, healthcare, employment, or other social indicators. Provide valuable insights to organizations for evidence-based decision-making.</li>
                <li><strong>Survey Researcher:</strong> Plan, design, and implement surveys to collect social and demographic data. Analyze survey data, interpret findings, and prepare reports. Work in market research firms, government agencies, or consulting companies.</li>
                <li><strong>Policy Analyst:</strong> Use your understanding of population dynamics and social statistics to assess and evaluate public policies. Work in government agencies, non-profit organizations, or research institutions to contribute to evidence-based policy-making.</li>
                <li><strong>Data Manager:</strong> Manage and maintain large datasets related to population or social indicators. Ensure data integrity, implement data quality control measures, and design databases. Work in government agencies, research organizations, or data management firms.</li>
                <li><strong>Project Manager:</strong> Use your strong analytical and organizational skills to manage research projects or social programs. Coordinate data collection efforts, oversee data analysis, and ensure project objectives are met.</li>
                <li><strong>Market Research Analyst:</strong> Apply demographic and statistical knowledge to analyze consumer behavior, market trends, and demographics for marketing purposes. Provide insights to businesses on target markets and customer preferences.</li>
                <li><strong>Policy Planner:</strong> Collaborate with government agencies or urban planning organizations to analyze population trends and contribute to urban and regional planning initiatives. Use demographic data to inform policy decisions related to housing, transportation, and infrastructure.</li>
            </ol>
          </div>
    
          <div id="tab4" class="tab-content">
            <p>The program cost at Yonevas Open University typically includes tuition fees, administrative fees, and access to digital learning resources. These resources  includes course materials, online libraries, and other digital platforms that support the learning process. The cost structure may vary depending on the specific program and its duration.</p>
            <table>
              <tr>
                <th>Program length</th>
                <th>Medium</th>
                <th>Est. Cost</th>
                <th>Begin/Term</th>
                <th>Award Offered</th>
              </tr>
              <tr>
                <td>8 semesters</td>
                <td>Virtual</td>
                <td>#84,000</td>
                <td>Sept./Feb</td>
                <td>Bachelors</td>
              </tr>
            </table>
          </div>
          <a href="/register">
            <button class="formbold-btn">
                Apply Now!
            </button>
          </a>
        </div>
      </main>
      
      <script>
        // Function to switch between tabs
        function openTab(event, tabId) {
          // Hide all tab contents
          var tabContents = document.getElementsByClassName("tab-content");
          for (var i = 0; i < tabContents.length; i++) {
            tabContents[i].style.display = "none";
          }
    
          // Remove the "active" class from all tab buttons
          var tabButtons = document.getElementsByClassName("tab-button");
          for (var i = 0; i < tabButtons.length; i++) {
            tabButtons[i].classList.remove("active");
          }
    
          // Show the selected tab content
          document.getElementById(tabId).style.display = "block";
    
          // Add the "active" class to the clicked button
          event.currentTarget.classList.add("active");
        }
        
        // Show the first tab by default
        document.getElementById("tab1").style.display = "block";
        document.getElementsByClassName("tab-button")[0].classList.add("active");
      </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.pages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/yonevasi/public_html/resources/views/USER/demograhpyandsocialstatistics.blade.php ENDPATH**/ ?>