<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make('ADMIN.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>



    <?php echo $__env->make('ADMIN.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('ADMIN.body', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Core -->
    <?php echo $__env->make('ADMIN.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>
<?php /**PATH /home/yonevasi/public_html/resources/views/ADMIN/home.blade.php ENDPATH**/ ?>