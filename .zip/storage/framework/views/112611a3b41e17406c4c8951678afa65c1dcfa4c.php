
<?php $__env->startSection('content'); ?>
    <main id="main" class="main">
        <a id="main-content" tabindex="-1"></a>
        <div class="region region-breadcrumb">
            <div data-drupal-messages-fallback class="hidden"></div>

            <div id="block-breadcrumbs"
                class="breadcrumb-block--overlay block breadcrumb-block block-system block-system-breadcrumb-block">
                <div class="breadcrumb-block__inner">
                    <div class="container">
                        <nav class="breadcrumb" role="navigation" aria-labelledby="system-breadcrumb">
                            <h2 id="system-breadcrumb" class="visually-hidden">Breadcrumb</h2>
                            <ol>
                                <li>
                                    <a href="/">Home</a>
                                </li>
                                <li>
                                    Social Science
                                </li>
                            </ol>
                        </nav>

                    </div>
                </div>
            </div>

        </div>

        <div class="main-region">
            <div class="region region-content">
                <div id="block-mainpagecontent" class="block block-system block-system-main-block">
                    <article data-history-node-id="27" role="article" about="/admissions"
                        class="node node--type-landing-page node--promoted node--view-mode-full">
                        <div class="node__content">
                            <div
                                class="field field--name-field-paragraphs field--type-entity-reference-revisions field--label-hidden field__items">
                                <div class="field__item" tabindex="0">
                                    <div>
                                        <div class="feature-banner has-image">
                                            <div class="feature-banner__image">
                                              <picture>
                                                  <img src="<?php echo e(asset('assets/img/degree-home.png')); ?>" alt="Pixels Bench"
                                                      title="pixel_bench_crop.png"
                                                      style="background-repeat: no-repeat; height:120%; width:100%; object-fit:cover;"
                                                      typeof="foaf:Image" />
                                              </picture>
                                            </div>
                                            <div class="feature-banner__content-wrap">
                                                <div class="container">
                                                    <div class="feature-banner__content text--center bg--black text--white">
                                                        <h1 class="feature-banner__title">Social Science</h1>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="field__item" tabindex="0">
                                    <div id="highlights">
                                        <div class="block-stats bg--white text--dark">
                                            <div class="container">
                                                <h1 class="block-stats__big-title text--center capitalize">Social Science
                                                    Courses</h1>
                                                <div class="block-stats__inner">
                                                    <div class="block-stats__list">
                                                        <ul id="boxes-f">
                                                            <li class="fm">
                                                                <a class="hvr-sweep-to-right ftiles"
                                                                    href="<?php echo e(route('economics')); ?>"><span
                                                                        class="blurb2">Economics</span></a>
                                                            </li>
                                                            <li class="fm">
                                                                <a class="hvr-sweep-to-right ftiles"
                                                                    href="<?php echo e(route('demograhpyandsocialstatistics')); ?>"><span
                                                                        class="blurb2" style="padding: 1rem" style="padding: 1rem">Demography and Social Statistics B.Sc.</span></a>
                                                            </li>
                                                            <li class="fm"><a class="hvr-sweep-to-right ftiles"
                                                                    href="<?php echo e(route('politicalScience')); ?>"><span class="blurb2" style="padding: 1rem">Political
                                                                        Science</span></a>
                                                            </li>
                                                            <li class="fm"><a class="hvr-sweep-to-right ftiles"
                                                                    href="<?php echo e(route('demograhpyandsocialstatistics')); ?>"><span
                                                                        class="blurb2" style="padding: 1rem">Psychology</span></a></li>
                                                            <li class="fm">
                                                                <a class="hvr-sweep-to-right ftiles"
                                                                    href="<?php echo e(route('developementStudies')); ?>"><span class="blurb2" style="padding: 1rem">Development Studies B.Sc.</span></a>
                                                            </li>
                                                            <li class="fm"><a class="hvr-sweep-to-right ftiles"
                                                                    href="<?php echo e(route('demograhpyandsocialstatistics')); ?>"><span
                                                                        class="blurb2" style="padding: 1rem">International Relations B.Sc.</span></a></li>
                                                            <li class="fm"><a class="hvr-sweep-to-right ftiles"
                                                                    href="<?php echo e(route('demograhpyandsocialstatistics')); ?>"><span class="blurb2" style="padding: 1rem">Social
                                                                        Work</span></a></li>
                                                            <li class="fm"><a class="hvr-sweep-to-right ftiles"
                                                                    href="<?php echo e(route('demograhpyandsocialstatistics')); ?>"><span
                                                                        class="blurb2" style="padding: 1rem">Sociology</span></a></li>
                                                            <li class="fm"><a class="hvr-sweep-to-right ftiles"
                                                                    href="<?php echo e(route('demograhpyandsocialstatistics')); ?>"><span
                                                                        class="blurb2" style="padding: 1rem">Statistics</span></a></li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>



                            </div>

                        </div>

                    </article>

                </div>

            </div>

        </div>
        </div>
        </div>
        </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.pages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ibrah\Desktop\Yonevas\16-6\resources\views/USER/socialScience.blade.php ENDPATH**/ ?>