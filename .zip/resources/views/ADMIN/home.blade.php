<!DOCTYPE html>
<html lang="en">

<head>
    @include('ADMIN.css')
</head>

<body>



    @include('ADMIN.navbar')

    @include('ADMIN.body')
    <!-- Core -->
    @include('ADMIN.script')
</body>

</html>
