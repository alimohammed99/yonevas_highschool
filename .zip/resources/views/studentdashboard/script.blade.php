<script src="../../studentdashboard/vendor/@popperjs/core/dist/umd/popper.min.js"></script>
<script src="../../studentdashboard/vendor/bootstrap/dist/js/bootstrap.min.js"></script>

<!-- Vendor JS -->
<script src="../../studentdashboard/vendor/onscreen/dist/on-screen.umd.min.js"></script>

<!-- Slider -->
<script src="../../studentdashboard/vendor/nouislider/distribute/nouislider.min.js"></script>

<!-- Smooth scroll -->
<script src="../../studentdashboard/vendor/smooth-scroll/dist/smooth-scroll.polyfills.min.js"></script>

<!-- Charts -->
<script src="../../studentdashboard/vendor/chartist/dist/chartist.min.js"></script>
<script src="../../studentdashboard/vendor/chartist-plugin-tooltips/dist/chartist-plugin-tooltip.min.js"></script>

<!-- Datepicker -->
<script src="../../studentdashboard/vendor/vanillajs-datepicker/dist/js/datepicker.min.js"></script>

<!-- Sweet Alerts 2 -->
<script src="../../studentdashboard/vendor/sweetalert2/dist/sweetalert2.all.min.js"></script>

<!-- Moment JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.27.0/moment.min.js"></script>

<!-- Vanilla JS Datepicker -->
<script src="../../studentdashboard/vendor/vanillajs-datepicker/dist/js/datepicker.min.js"></script>

<!-- Notyf -->
<script src="../../studentdashboard/vendor/notyf/notyf.min.js"></script>

<!-- Simplebar -->
<script src="../../studentdashboard/vendor/simplebar/dist/simplebar.min.js"></script>

<!-- Github buttons -->
<script async defer src="https://buttons.github.io/buttons.js"></script>

<!-- Volt JS -->
<script src="../../studentdashboard/assets/js/volt.js"></script>










<script src="{{ asset('studentdashboard/vendor/jquery/jquery.min.js') }}"></script>
<script src="{{ asset('studentdashboard/vendor/popper.js/umd/popper.min.js') }}"></script>
<script src="{{ asset('studentdashboard/vendor/bootstrap/js/bootstrap.min.js') }}"></script>
<script src="{{ asset('studentdashboard/vendor/jquery.cookie/jquery.cookie.js') }}"></script>
<script src="{{ asset('studentdashboard/vendor/chart.js/Chart.min.js') }}"></script>
<script src="{{ asset('studentdashboard/vendor/jquery-validation/jquery.validate.min.js') }}"></script>
<script src="{{ asset('studentdashboard/js/charts-home.js') }}"></script>
<script src="{{ asset('studentdashboard/js/front.js') }}"></script>





<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.12.1/js/dataTables.bootstrap4.min.js"></script>





<script>
    $(document).ready(function() {
        $('#example').DataTable();
    });
</script>

{{-- <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.min.js" integrity="sha384-+sLIOodYLS7CIrQpBjl+C7nPvqq+FbNUBDunl/OZv93DB7Ln/533i8e/mZXLi/P+" crossorigin="anonymous"></script> --}}
