<!DOCTYPE html>
<html>
<head>
    <title>Error</title>
</head>
<body>
<h3 style="text-decoration: underline; color:tomato">PAGE NOT FOUND</h3>
</body>
</html>
<?php /**PATH C:\Users\ibrah\Desktop\Yonevas\16-6\resources\views/errors/404.blade.php ENDPATH**/ ?>