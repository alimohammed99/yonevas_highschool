<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make('studentdashboard.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>



    <?php echo $__env->make('studentdashboard.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php if(session()->has('success_message')): ?>
        <div class="alert alert-success alert-dismissible">
            <button class="close" type="button" data-dismiss="alert">x</button>
            <?php echo e(session()->get('success_message')); ?>

        </div>
    <?php endif; ?>


    <?php if(session()->has('error_message')): ?>
        <div class="alert alert-danger alert-dismissible">
            <button class="close" type="button" data-dismiss="alert">x</button>
            <?php echo e(session()->get('error_message')); ?>

        </div>
    <?php endif; ?>



    <?php echo $__env->make('studentdashboard.body', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Core -->
    <?php echo $__env->make('studentdashboard.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>
<?php /**PATH /home/yonevasi/public_html/resources/views/studentdashboard/home.blade.php ENDPATH**/ ?>